/**
 * theme.js
 * -----------------------------------------------------------------
 * Site-wide settings menu (☰, top-left):
 *   - Theme: dark / light / custom wallpaper
 *   - Text: black or white text on game cards
 *   - Cards: background color for game cards (red/blue/yellow/green/orange)
 *
 * Fully self-contained — just include this on any page:
 *
 *   <script src="theme.js"></script>
 *
 * No extra HTML or CSS needed. It builds its own hamburger button
 * and dropdown panel, and injects its own stylesheet. The "Cards"
 * and "Text" options only visually affect elements with class
 * "card" (the game cards on coop-library.html) — harmless no-op
 * on pages without any.
 *
 * Everything is saved in localStorage, so choices stay applied
 * across pages and future visits.
 * -----------------------------------------------------------------
 */
(function () {
  const THEMES = {
    dark: {
      "--bg": "#0e1016",
      "--bg-alt": "#151824",
      "--surface": "#1b1f2e",
      "--surface-hover": "#212639",
      "--border": "#2a3044",
      "--text": "#eef1f7",
      "--text-dim": "#9aa0b8",
      "--text-faint": "#5e6478"
    },
    light: {
      "--bg": "#f3f4f8",
      "--bg-alt": "#e7e9f0",
      "--surface": "#ffffff",
      "--surface-hover": "#f2f3f8",
      "--border": "#d7dae3",
      "--text": "#181b24",
      "--text-dim": "#4c5166",
      "--text-faint": "#7a8098"
    }
  };

  const CARD_COLORS = {
    red: "#e5484d",
    blue: "#3b82f6",
    yellow: "#f5c518",
    green: "#22c55e",
    orange: "#f97316"
  };
  const TEXT_COLORS = { black: "#000000", white: "#ffffff" };

  const KEY_THEME = "siteTheme";        // "dark" | "light" | "custom"
  const KEY_IMAGE = "siteCustomImage";  // data URL of the wallpaper
  const KEY_BASE = "siteCustomBase";    // "dark" | "light" — palette used under the wallpaper
  const KEY_CARD_COLOR = "siteCardColor"; // "red" | "blue" | "yellow" | "green" | "orange" | null
  const KEY_CARD_TEXT = "siteCardText";   // "black" | "white" | null

  const STYLE = `
    body{ padding-top: 84px !important; }
    @media (max-width:520px){ body{ padding-top: 76px !important; } }

    .theme-menu-btn{
      position:fixed; top:20px; left:20px; z-index:1000;
      width:40px; height:40px;
      display:flex; align-items:center; justify-content:center;
      background:var(--surface, #1b1f2e);
      border:1px solid var(--border, #2a3044);
      border-radius:10px;
      color:var(--text, #eef1f7);
      font-size:17px;
      cursor:pointer;
      transition: all 0.15s ease;
    }
    .theme-menu-btn:hover{ border-color:var(--text-faint, #5e6478); }

    .theme-panel{
      position:fixed; top:66px; left:20px; z-index:1000;
      background:var(--surface, #1b1f2e);
      border:1px solid var(--border, #2a3044);
      border-radius:12px;
      padding:14px;
      display:none;
      flex-direction:column;
      gap:8px;
      min-width:190px;
      box-shadow:0 10px 30px rgba(0,0,0,0.35);
      font-family:'Space Grotesk', sans-serif;
    }
    .theme-panel.open{ display:flex; }

    .theme-panel-label{
      font-family:'IBM Plex Mono', monospace;
      font-size:10.5px;
      letter-spacing:0.08em;
      text-transform:uppercase;
      color:var(--text-faint, #5e6478);
    }
    .theme-panel-label:not(:first-child){ margin-top:6px; }

    .theme-switch-row{ display:flex; gap:6px; align-items:center; flex-wrap:wrap; }

    .swatch-btn{
      width:26px; height:26px;
      border-radius:7px;
      border:1px solid var(--border, #2a3044);
      cursor:pointer;
      padding:0;
      flex-shrink:0;
      transition: all 0.15s ease;
    }
    .swatch-btn:hover{ transform:scale(1.1); }
    .swatch-btn.active{
      box-shadow:0 0 0 2px var(--surface, #1b1f2e), 0 0 0 4px #5b9dff;
    }

    .theme-swatch-custom{
      background: conic-gradient(from 180deg, #ff6b81, #ffb84d, #5ce1a0, #5b9dff, #ff6b81);
    }

    .theme-remove-btn{
      display:flex; align-items:center; justify-content:center;
      width:26px; height:26px;
      font-size:12px;
      color:var(--text-dim, #9aa0b8);
      background:var(--bg, #0e1016);
      border:1px solid var(--border, #2a3044);
      border-radius:50%;
      cursor:pointer;
      transition: all 0.15s ease;
    }
    .theme-remove-btn:hover{ color:var(--text, #eef1f7); border-color:var(--text-faint, #5e6478); }
  `;

  function injectStyle() {
    const el = document.createElement("style");
    el.textContent = STYLE;
    document.head.appendChild(el);
  }

  function applyVars(vars) {
    const root = document.documentElement.style;
    Object.entries(vars).forEach(([k, v]) => root.setProperty(k, v));
  }

  function clearWallpaper() {
    document.body.style.backgroundImage = "";
    document.body.classList.remove("has-custom-bg");
  }

  function applyWallpaper(dataUrl) {
    // Dark scrim under the image keeps existing text readable regardless
    // of what the photo looks like.
    document.body.style.backgroundImage =
      `linear-gradient(rgba(6,8,14,0.6), rgba(6,8,14,0.6)), url("${dataUrl}")`;
    document.body.style.backgroundSize = "cover";
    document.body.style.backgroundPosition = "center";
    document.body.style.backgroundAttachment = "fixed";
    document.body.classList.add("has-custom-bg");
  }

  function setTheme(mode) {
    localStorage.setItem(KEY_THEME, mode);

    if (mode === "custom") {
      const base = localStorage.getItem(KEY_BASE) || "dark";
      applyVars(THEMES[base]);
      const img = localStorage.getItem(KEY_IMAGE);
      if (img) applyWallpaper(img);
    } else {
      applyVars(THEMES[mode] || THEMES.dark);
      clearWallpaper();
    }
    updateActiveStates();
  }

  // --- Game-card color + text overrides ---
  function applyCardOverride() {
    let styleEl = document.getElementById("cardColorOverride");
    if (!styleEl) {
      styleEl = document.createElement("style");
      styleEl.id = "cardColorOverride";
      document.head.appendChild(styleEl);
    }
    const colorKey = localStorage.getItem(KEY_CARD_COLOR);
    if (!colorKey || !CARD_COLORS[colorKey]) {
      styleEl.textContent = "";
      return;
    }
    const bg = CARD_COLORS[colorKey];
    const textKey = localStorage.getItem(KEY_CARD_TEXT) || "black";
    const text = TEXT_COLORS[textKey] || TEXT_COLORS.black;
    styleEl.textContent = `
      .card{ background:${bg} !important; }
      .card .name, .card .note{ color:${text} !important; }
    `;
  }

  function setCardColor(colorKey) {
    const current = localStorage.getItem(KEY_CARD_COLOR);
    if (current === colorKey) {
      localStorage.removeItem(KEY_CARD_COLOR); // clicking the active one again clears it
    } else {
      localStorage.setItem(KEY_CARD_COLOR, colorKey);
    }
    applyCardOverride();
    updateActiveStates();
  }

  function setCardText(textKey) {
    const current = localStorage.getItem(KEY_CARD_TEXT);
    if (current === textKey) {
      localStorage.removeItem(KEY_CARD_TEXT);
    } else {
      localStorage.setItem(KEY_CARD_TEXT, textKey);
    }
    applyCardOverride();
    updateActiveStates();
  }

  function updateActiveStates() {
    const themeMode = localStorage.getItem(KEY_THEME) || "dark";
    document.querySelectorAll(".theme-swatch").forEach(b => {
      b.classList.toggle("active", b.dataset.theme === themeMode);
    });
    const removeBtn = document.querySelector(".theme-remove-btn");
    if (removeBtn) removeBtn.style.display = (themeMode === "custom") ? "inline-flex" : "none";

    const cardColor = localStorage.getItem(KEY_CARD_COLOR);
    document.querySelectorAll(".card-color-btn").forEach(b => {
      b.classList.toggle("active", b.dataset.color === cardColor);
    });

    const cardText = localStorage.getItem(KEY_CARD_TEXT);
    document.querySelectorAll(".card-text-btn").forEach(b => {
      b.classList.toggle("active", b.dataset.text === cardText);
    });
  }

  // Downscale + compress the chosen photo before storing it, so it
  // fits comfortably in localStorage and loads fast.
  function resizeImage(file, maxWidth, quality, cb) {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxWidth / img.width);
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
        cb(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = () => cb(null);
      img.src = e.target.result;
    };
    reader.onerror = () => cb(null);
    reader.readAsDataURL(file);
  }

  function buildMenu() {
    const menuBtn = document.createElement("button");
    menuBtn.type = "button";
    menuBtn.className = "theme-menu-btn";
    menuBtn.setAttribute("aria-label", "Settings");
    menuBtn.textContent = "☰";

    const panel = document.createElement("div");
    panel.className = "theme-panel";
    panel.innerHTML = `
      <div class="theme-panel-label">Theme</div>
      <div class="theme-switch-row">
        <button class="swatch-btn theme-swatch" data-theme="dark" type="button" title="Dark theme" style="background:#0e1016;"></button>
        <button class="swatch-btn theme-swatch" data-theme="light" type="button" title="Light theme" style="background:#f3f4f8;"></button>
        <button class="swatch-btn theme-swatch theme-swatch-custom" data-theme="custom" type="button" title="Custom wallpaper"></button>
        <button class="theme-remove-btn" type="button" title="Remove wallpaper" style="display:none;">✕</button>
      </div>
      <input type="file" class="theme-image-input" accept="image/*" style="display:none;">

      <div class="theme-panel-label">Text</div>
      <div class="theme-switch-row">
        <button class="swatch-btn card-text-btn" data-text="black" type="button" title="Black text" style="background:#000000;"></button>
        <button class="swatch-btn card-text-btn" data-text="white" type="button" title="White text" style="background:#ffffff;"></button>
      </div>

      <div class="theme-panel-label">Cards</div>
      <div class="theme-switch-row">
        <button class="swatch-btn card-color-btn" data-color="red" type="button" title="Red" style="background:${CARD_COLORS.red};"></button>
        <button class="swatch-btn card-color-btn" data-color="blue" type="button" title="Blue" style="background:${CARD_COLORS.blue};"></button>
        <button class="swatch-btn card-color-btn" data-color="yellow" type="button" title="Yellow" style="background:${CARD_COLORS.yellow};"></button>
        <button class="swatch-btn card-color-btn" data-color="green" type="button" title="Green" style="background:${CARD_COLORS.green};"></button>
        <button class="swatch-btn card-color-btn" data-color="orange" type="button" title="Orange" style="background:${CARD_COLORS.orange};"></button>
      </div>
    `;

    document.body.appendChild(menuBtn);
    document.body.appendChild(panel);

    menuBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      panel.classList.toggle("open");
    });
    document.addEventListener("click", (e) => {
      if (!panel.contains(e.target) && e.target !== menuBtn) panel.classList.remove("open");
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") panel.classList.remove("open");
    });

    const fileInput = panel.querySelector(".theme-image-input");

    panel.querySelectorAll(".theme-swatch").forEach(btn => {
      btn.addEventListener("click", () => {
        const mode = btn.dataset.theme;
        if (mode === "custom") {
          const hasImage = !!localStorage.getItem(KEY_IMAGE);
          const currentMode = localStorage.getItem(KEY_THEME);
          if (currentMode === "custom") {
            // Already on custom — clicking again lets you swap the photo.
            fileInput.click();
            return;
          }
          if (!hasImage) {
            fileInput.click();
            return;
          }
          const prev = localStorage.getItem(KEY_THEME);
          if (prev === "dark" || prev === "light") localStorage.setItem(KEY_BASE, prev);
          setTheme("custom");
        } else {
          setTheme(mode);
        }
      });
    });

    fileInput.addEventListener("change", (e) => {
      const file = e.target.files[0];
      if (!file) return;
      resizeImage(file, 1920, 0.82, (dataUrl) => {
        if (!dataUrl) {
          alert("Couldn't read that image — try a different file.");
          return;
        }
        try {
          localStorage.setItem(KEY_IMAGE, dataUrl);
        } catch (err) {
          alert("That image is too large to save. Try a smaller one.");
          return;
        }
        const prev = localStorage.getItem(KEY_THEME);
        if (prev === "dark" || prev === "light") localStorage.setItem(KEY_BASE, prev);
        setTheme("custom");
      });
      fileInput.value = "";
    });

    const removeBtn = panel.querySelector(".theme-remove-btn");
    removeBtn.addEventListener("click", () => {
      localStorage.removeItem(KEY_IMAGE);
      const base = localStorage.getItem(KEY_BASE) || "dark";
      setTheme(base);
    });

    panel.querySelectorAll(".card-color-btn").forEach(btn => {
      btn.addEventListener("click", () => setCardColor(btn.dataset.color));
    });
    panel.querySelectorAll(".card-text-btn").forEach(btn => {
      btn.addEventListener("click", () => setCardText(btn.dataset.text));
    });
  }

  function init() {
    injectStyle();
    buildMenu();
    const savedTheme = localStorage.getItem(KEY_THEME) || "dark";
    setTheme(savedTheme);
    applyCardOverride();
    updateActiveStates();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
